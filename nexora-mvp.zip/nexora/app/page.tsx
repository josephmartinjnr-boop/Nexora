 "use client";

import { useEffect, useMemo, useState } from "react";

type Task = { id: string; title: string; done: boolean };
type Goal = { id: string; title: string; category: string; deadline: string; tasks: Task[]; createdAt: string };
type Chat = { role: "assistant" | "user"; text: string };

const starterGoals: Goal[] = [
  { id: "g1", title: "Build a consistent morning routine", category: "Personal growth", deadline: "", createdAt: new Date().toISOString(), tasks: [
    { id: "t1", title: "Choose a realistic wake-up time", done: true },
    { id: "t2", title: "Plan tomorrow before bed", done: false },
    { id: "t3", title: "Complete a 15-minute morning routine", done: false }
  ]},
  { id: "g2", title: "Grow my professional skills", category: "Career", deadline: "", createdAt: new Date().toISOString(), tasks: [
    { id: "t4", title: "Choose one skill to develop", done: false },
    { id: "t5", title: "Schedule two learning sessions", done: false }
  ]}
];

function Icon({ name }: { name: string }) {
  const common = { width: 18, height: 18, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const paths: Record<string, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-6h6v6"/></>,
    target: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></>,
    check: <><path d="m5 12 4 4L19 6"/></>,
    chart: <><path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 6-7"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.6.9l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.6-.9l-1.7.7-1.4-2.4 1.4-1.1a7 7 0 0 1 0-1.9l-1.4-1.1 1.4-2.4 1.7.7a8 8 0 0 1 1.6-.9l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.6.9l1.7-.7 1.4 2.4-1.4 1.1a7 7 0 0 1 0 1.9Z"/></>,
    spark: <><path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    send: <><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></>
  };
  return <svg {...common}>{paths[name] || paths.spark}</svg>;
}

export default function Home() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [ready, setReady] = useState(false);
  const [active, setActive] = useState("Overview");
  const [modal, setModal] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Personal growth");
  const [deadline, setDeadline] = useState("");
  const [taskDraft, setTaskDraft] = useState<Record<string,string>>({});
  const [chatInput, setChatInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [chat, setChat] = useState<Chat[]>([{ role: "assistant", text: "Hi! I'm your Nexora coach. What would you like to make progress on today?" }]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("nexora-goals-v1");
      setGoals(saved ? JSON.parse(saved) : starterGoals);
    } catch { setGoals(starterGoals); }
    setReady(true);
  }, []);
  useEffect(() => { if (ready) localStorage.setItem("nexora-goals-v1", JSON.stringify(goals)); }, [goals, ready]);

  const totalTasks = goals.reduce((n,g) => n + g.tasks.length, 0);
  const doneTasks = goals.reduce((n,g) => n + g.tasks.filter(t => t.done).length, 0);
  const progress = totalTasks ? Math.round(doneTasks / totalTasks * 100) : 0;
  const completedGoals = goals.filter(g => g.tasks.length > 0 && g.tasks.every(t => t.done)).length;
  const today = new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric" }).format(new Date());

  function addGoal(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setGoals(prev => [{ id: crypto.randomUUID(), title: title.trim(), category, deadline, createdAt: new Date().toISOString(), tasks: [] }, ...prev]);
    setTitle(""); setDeadline(""); setCategory("Personal growth"); setModal(false); setActive("My Goals");
  }
  function toggleTask(goalId: string, taskId: string) {
    setGoals(prev => prev.map(g => g.id === goalId ? { ...g, tasks: g.tasks.map(t => t.id === taskId ? { ...t, done: !t.done } : t) } : g));
  }
  function addTask(goalId: string) {
    const value = (taskDraft[goalId] || "").trim();
    if (!value) return;
    setGoals(prev => prev.map(g => g.id === goalId ? { ...g, tasks: [...g.tasks, { id: crypto.randomUUID(), title: value, done: false }] } : g));
    setTaskDraft(prev => ({ ...prev, [goalId]: "" }));
  }
  async function sendChat(e: React.FormEvent) {
    e.preventDefault();
    const message = chatInput.trim();
    if (!message || busy) return;
    setChat(prev => [...prev, { role: "user", text: message }]); setChatInput(""); setBusy(true);
    try {
      const res = await fetch("/api/coach", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message, goals: goals.map(g => ({ title: g.title, category: g.category, tasks: g.tasks })) }) });
      const data = await res.json();
      setChat(prev => [...prev, { role: "assistant", text: data.reply || data.error || "Let's break that down into a manageable next step." }]);
    } catch { setChat(prev => [...prev, { role: "assistant", text: "I couldn't reach the coach just now. Please try again." }]); }
    finally { setBusy(false); }
  }

  const nav = [{ name: "Overview", icon: "home" }, { name: "My Goals", icon: "target" }, { name: "Action Plan", icon: "check" }, { name: "Progress", icon: "chart" }, { name: "Calendar", icon: "calendar" }];
  const visibleGoals = useMemo(() => active === "Action Plan" ? goals.filter(g => g.tasks.some(t => !t.done)) : goals, [goals, active]);

  if (!ready) return <main className="loading">NEXORA<span>.</span></main>;

  return <main className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#"><span className="brand-mark">N</span><span>NEXORA<span className="brand-dot">.</span></span></a>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.name} onClick={() => setActive(item.name)} className={`nav-item ${active === item.name ? "selected" : ""}`}><Icon name={item.icon}/>{item.name}{item.name === "My Goals" && <span className="nav-count">{goals.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom">
        <div className="upgrade-card"><div className="spark-circle"><Icon name="spark"/></div><strong>Your next chapter starts here.</strong><p>Small steps. Meaningful progress.</p></div>
        <button className="nav-item"><Icon name="settings"/>Settings</button>
        <div className="profile"><div className="avatar">Y</div><div><strong>Your workspace</strong><small>Personal account</small></div><span className="dots">•••</span></div>
      </div>
    </aside>

    <section className="main-area">
      <header className="topbar"><div className="mobile-brand"><span className="brand-mark">N</span> NEXORA<span className="brand-dot">.</span></div><div className="breadcrumb">Workspace <span>/</span> {active}</div><div className="top-actions"><span className="today-label"><Icon name="calendar"/> {today}</span><div className="avatar small">Y</div></div></header>
      <div className="content">
        <div className="welcome-row"><div><div className="eyebrow">YOUR PERSONAL ACHIEVEMENT SPACE</div><h1>{active === "Overview" ? "Make today count." : active}</h1><p className="subtitle">{active === "Overview" ? "A little progress each day adds up to big results." : "Keep your attention on what matters most."}</p></div><button className="primary-btn" onClick={() => setModal(true)}><Icon name="plus"/> New goal</button></div>

        <div className="stats-grid">
          <div className="stat-card"><div className="stat-top"><span>Active goals</span><span className="stat-icon purple"><Icon name="target"/></span></div><strong>{goals.length}</strong><small>Ambitions in motion</small></div>
          <div className="stat-card"><div className="stat-top"><span>Tasks completed</span><span className="stat-icon green"><Icon name="check"/></span></div><strong>{doneTasks}<small className="of-total"> / {totalTasks}</small></strong><small>Actions taken so far</small></div>
          <div className="stat-card"><div className="stat-top"><span>Overall progress</span><span className="stat-icon gold"><Icon name="chart"/></span></div><strong>{progress}%</strong><div className="mini-track"><span style={{width: `${progress}%`}}/></div></div>
          <div className="stat-card"><div className="stat-top"><span>Goals completed</span><span className="stat-icon blue"><Icon name="spark"/></span></div><strong>{completedGoals}</strong><small>Milestones worth celebrating</small></div>
        </div>

        <div className="dashboard-grid">
          <section className="panel goals-panel">
            <div className="panel-heading"><div><h2>{active === "Action Plan" ? "Your next actions" : "Your goals"}</h2><p>Turn intention into momentum.</p></div><button className="text-btn" onClick={() => setActive("My Goals")}>View all <Icon name="arrow"/></button></div>
            {visibleGoals.length === 0 ? <div className="empty-state"><div className="empty-icon"><Icon name="target"/></div><strong>No goals yet</strong><p>Create a goal and give your next chapter a direction.</p><button className="primary-btn" onClick={() => setModal(true)}><Icon name="plus"/> Create a goal</button></div> :
              <div className="goal-list">{visibleGoals.map(goal => {
                const done = goal.tasks.filter(t => t.done).length;
                const pct = goal.tasks.length ? Math.round(done / goal.tasks.length * 100) : 0;
                return <article className="goal-item" key={goal.id}>
                  <div className="goal-line"><div className="goal-symbol"><Icon name="target"/></div><div className="goal-info"><div className="goal-title-row"><h3>{goal.title}</h3><span className="category">{goal.category}</span></div><div className="goal-meta">{goal.deadline ? `Due ${new Date(goal.deadline + "T00:00:00").toLocaleDateString()}` : "No deadline set"} <span>·</span> {done}/{goal.tasks.length} tasks complete</div></div><strong className="goal-percent">{pct}%</strong></div>
                  <div className="progress-track"><span style={{width: `${pct}%`}}/></div>
                  <div className="task-list">{goal.tasks.map(task => <label className={`task-row ${task.done ? "task-done" : ""}`} key={task.id}><input type="checkbox" checked={task.done} onChange={() => toggleTask(goal.id, task.id)}/><span>{task.title}</span></label>)}</div>
                  <form className="add-task" onSubmit={e => { e.preventDefault(); addTask(goal.id); }}><input aria-label="Add an action" placeholder="Add a next action..." value={taskDraft[goal.id] || ""} onChange={e => setTaskDraft(p => ({...p, [goal.id]: e.target.value}))}/><button aria-label="Add task"><Icon name="plus"/></button></form>
                </article>;
              })}</div>}
          </section>

          <aside className="right-column">
            <section className="coach-panel">
              <div className="coach-heading"><div className="coach-orb"><Icon name="spark"/></div><div><span className="eyebrow">NEXORA INTELLIGENCE</span><h2>Your AI coach</h2></div><span className="online-dot"/></div>
              <p className="coach-intro">A thoughtful partner for turning your ideas into achievable next steps.</p>
              <div className="chat-window">{chat.map((m,i) => <div key={i} className={`chat-message ${m.role}`}><div className="chat-avatar">{m.role === "assistant" ? <Icon name="spark"/> : "Y"}</div><div className="chat-bubble">{m.text}</div></div>)}{busy && <div className="typing">Nexora is thinking<span> ···</span></div>}</div>
              <form className="chat-form" onSubmit={sendChat}><input value={chatInput} onChange={e => setChatInput(e.target.value)} placeholder="Ask Nexora anything..." aria-label="Message Nexora"/><button disabled={busy || !chatInput.trim()} aria-label="Send message"><Icon name="send"/></button></form>
              <div className="suggestions"><button onClick={() => setChatInput("Help me turn a big goal into smaller steps.")}>Break down a goal</button><button onClick={() => setChatInput("Help me plan my week.")}>Plan my week</button></div>
            </section>
            <section className="focus-panel"><div className="panel-heading"><div><h2>Daily focus</h2><p>One step at a time.</p></div><span className="focus-date">{new Date().getDate()}</span></div><div className="focus-progress"><div className="focus-ring" style={{"--progress": `${progress}%`} as React.CSSProperties}><strong>{progress}%</strong></div><div><strong>You're building momentum.</strong><p>{doneTasks} of {totalTasks} actions completed across your goals.</p></div></div></section>
          </aside>
        </div>
        <footer>© {new Date().getFullYear()} Nexora. Your ambition, in motion. <span>Built for progress.</span></footer>
      </div>
    </section>

    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal(false); }}><form className="modal" onSubmit={addGoal}><button type="button" className="modal-close" onClick={() => setModal(false)}>×</button><div className="eyebrow">START SOMETHING MEANINGFUL</div><h2>Create a new goal</h2><p>Give your ambition a name. You can add actions right after.</p><label>Goal name<input autoFocus required value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Launch my first business"/></label><label>Area of life<select value={category} onChange={e => setCategory(e.target.value)}><option>Personal growth</option><option>Career</option><option>Business</option><option>Health & wellbeing</option><option>Education</option><option>Finance</option><option>Relationships</option><option>Other</option></select></label><label>Target date <span className="optional">(optional)</span><input type="date" value={deadline} onChange={e => setDeadline(e.target.value)}/></label><button className="primary-btn modal-submit">Create goal <Icon name="arrow"/></button></form></div>}
  </main>;
}

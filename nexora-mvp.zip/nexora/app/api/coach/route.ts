import OpenAI from "openai";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { message, goals = [] } = await request.json();
    if (typeof message !== "string" || !message.trim()) {
      return NextResponse.json({ error: "Please enter a message." }, { status: 400 });
    }
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({
        reply: "Your Nexora AI connection is not configured yet. Add OPENAI_API_KEY to your .env.local file to activate your personal coach. In the meantime, you can create goals and track tasks from your dashboard."
      });
    }
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      messages: [
        {
          role: "system",
          content: "You are Nexora, a practical, encouraging goal-achievement coach. Help users turn ambitions into specific, measurable, realistic next actions. Ask concise clarifying questions when needed. Avoid guaranteeing outcomes. Prefer clear steps, milestones, and a useful action the user can take today. Be inclusive and respectful."
        },
        {
          role: "user",
          content: `Current goals: ${JSON.stringify(goals)}\n\nUser message: ${message}`
        }
      ],
      temperature: 0.7
    });
    return NextResponse.json({ reply: completion.choices[0]?.message?.content || "Let's take this one step at a time. What would you like to achieve first?" });
  } catch {
    return NextResponse.json({ error: "The coach is temporarily unavailable. Please try again." }, { status: 500 });
  }
}

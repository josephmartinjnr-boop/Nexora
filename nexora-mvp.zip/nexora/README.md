# Nexora

**Think Bigger. Plan Smarter. Achieve More.**

Nexora is a free, AI-assisted goal achievement workspace. It helps people turn ambitions into practical action plans, track tasks, and reflect on progress.

## Current MVP

- Responsive dashboard for desktop and mobile browsers
- Create goals with categories and optional target dates
- Add tasks to goals and mark tasks complete
- Progress calculations across goals and tasks
- Daily focus summary
- AI coach API route (requires an OpenAI API key)
- Local browser storage for prototype goals

## Run locally

Requirements: Node.js 20.9 or later.

```bash
npm install
cp .env.example .env.local
```

Add your OpenAI API key to `.env.local` to enable live AI coaching:

```env
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4.1-mini
```

Then start the development server:

```bash
npm run dev
```

Open http://localhost:3000.

Without an API key, the dashboard and goal-tracking features still work. The coach explains that its connection is not configured.

## Important MVP limitations

- Goals are stored in the current browser only. Clearing browser storage or using another device will not sync them.
- There is no account registration, cloud database, automated reminder delivery, or native mobile app yet.
- Do not commit `.env.local` or expose API keys in client-side code.
- This is an initial product foundation, not a production-ready service.

## Roadmap

1. Foundation: product identity, responsive web app, onboarding and secure accounts.
2. Goal management: milestones, task planning, deadlines and recurring reviews.
3. AI intelligence: goal decomposition, coaching, progress-aware recommendations.
4. Accountability: reminders, check-ins and weekly reviews.
5. Mobile: Android and iOS apps with synchronized accounts.
6. Growth: integrations, accessibility, localization and optional collaboration.

## Suggested next engineering milestone

Add Supabase authentication and PostgreSQL tables for profiles, goals, milestones, tasks and check-ins. Enforce row-level security so each user can only access their own data.
